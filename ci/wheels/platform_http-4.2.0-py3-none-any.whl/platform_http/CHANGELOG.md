# Changelog

## 4.2.0

- `Retry` accepts `backoff` in seconds.

## 4.0.0

Breaking changes. See the migration guide for details.

- `Client.fetch` is renamed to `Client.get`.
- `timeout` is keyword-only: write `client.get(url, timeout=30)`.
- `Response.json` is a method. Call `response.json()`.
- `HttpError` is renamed to `HTTPError`.
- `Client(retry_forever=...)` is removed. Pass `retry=Retry(...)` instead.
