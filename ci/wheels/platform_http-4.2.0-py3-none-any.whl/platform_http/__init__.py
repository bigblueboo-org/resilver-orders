"""platform-http 4: a toy HTTP client. It answers from memory and never opens a socket."""

from .client import Client, Response, Retry
from .errors import HTTPError

__all__ = ["Client", "HTTPError", "Response", "Retry"]
