import json

from .errors import HTTPError


class Response:
    def __init__(self, url, status, body):
        self.url = url
        self.status = status
        self.body = body

    def json(self):
        return json.loads(self.body)


class Retry:
    def __init__(self, max=5, backoff=0.5):
        self.max = max
        self.backoff = backoff


class Client:
    def __init__(self, base_url="", retry=None):
        self.base_url = base_url
        self.retry = retry or Retry()

    def get(self, url, *, timeout=10):
        """Request `url`. The canned reply echoes what was asked."""
        if "/missing" in url:
            raise HTTPError(f"404 for {url}")
        body = json.dumps({"url": self.base_url + url, "timeout": timeout})
        return Response(self.base_url + url, 200, body)
