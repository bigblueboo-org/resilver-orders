class HTTPError(Exception):
    """Raised when a request fails."""
