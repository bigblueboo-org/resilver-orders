class HttpError(Exception):
    """Raised when a request fails."""
