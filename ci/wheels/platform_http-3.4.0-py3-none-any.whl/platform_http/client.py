import json

from .errors import HttpError


class Response:
    def __init__(self, url, status, body):
        self.url = url
        self.status = status
        self.body = body

    @property
    def json(self):
        return json.loads(self.body)


class Client:
    def __init__(self, base_url="", retry_forever=False):
        self.base_url = base_url
        self.retry_forever = retry_forever

    def fetch(self, url, timeout=10):
        """Request `url`. The canned reply echoes what was asked."""
        if "/missing" in url:
            raise HttpError(f"404 for {url}")
        body = json.dumps({"url": self.base_url + url, "timeout": timeout})
        return Response(self.base_url + url, 200, body)
