"""platform-http 3: a toy HTTP client. It answers from memory and never opens a socket."""

from .client import Client, Response
from .errors import HttpError

__all__ = ["Client", "HttpError", "Response"]
